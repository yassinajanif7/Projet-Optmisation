#include <stdio.h>
#include <stdlib.h>

double *create_vect(size_t size)
{
  double *res=(double *)malloc(sizeof(double)*size);
  return res;
}
  
void init_vect(double *vec, double value, size_t size)
{
  for (int i=0; i<size; i++)
    {
      vec[i] = value;
    }
}

void reset_vect(double *vec, size_t size)
{
  for (int i=0; i<size; i++)
    {
      vec[i] = 0.0;
    }
}

void dump_vect(double *v, size_t size)
{
  printf("[");
  for (int i=0; i<size; i++)
    {
      printf("%lf, ",v[i]);
    }
  printf("]\n");
}

