#include <stdio.h>

#include "common.h"
#include "ddot.h"

int main()
{
  const int Size=4;
  // Creer v1 et v2
  double *v1=create_vect(Size);
  init_vect(v1,1.0,Size);

  double *v2=create_vect(Size);
  init_vect(v2,2.0,Size);


  dump_vect(v1,Size);
  dump_vect(v2,Size);
  
  // Applicaquer la fonction ddot
  double res=ddot(v1, v2, Size);

  // Afficher le résultat
  if (res == (2.0*Size))
    printf("[Test-001] OK\n");
  else
    printf("[Test-001] Failed : res=%lf\n",res);

  return 0;
}
