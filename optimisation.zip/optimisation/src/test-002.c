#include <stdio.h>

#include "common.h"
#include "dgemm.h"

int main()
{
  const int Size=4;
  // Creer m1, m2, m3
  double **m1=create_mat(Size);
  init_mat(m1,1.0,Size);

  double **m2=create_mat(Size);
  init_mat(m2,2.0,Size);

  double **m3=create_mat(Size);
  init_mat(m3,0.0,Size);


  printf("M1:\n");
  dump_mat(m1,Size);
  printf("M2:\n");
  dump_mat(m2,Size);
  
  // Applicaquer la fonction ddot
  dgemm(m3, m1, m2, Size);

  printf("M3:\n");
  dump_mat(m3,Size);
  // Afficher le résultat

  return 0;
}
