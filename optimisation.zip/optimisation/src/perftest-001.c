#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#include "common.h"
#include "dgemm.h"

extern __inline__ uint64_t rdtsc(void)
{
  uint64_t a, d;
  __asm__ volatile ("rdtsc" : "=a" (a), "=d" (d));
  return (d<<32) | a;
}


int main(int argc, char **argv)
{
  int Size;
  if (argc>1)
    {
      Size=atoi(argv[1]);
    }
  else
    {
      printf("Usage: %s <size>\n",argv[0]);
    }
  
  // Creer m1, m2, m3
  double **m1=create_mat(Size);
  init_mat(m1,1.0,Size);

  double **m2=create_mat(Size);
  init_mat(m2,0.5,Size);

  double **m3=create_mat(Size);
  init_mat(m3,0.0,Size);

  uint64_t start = rdtsc(); 
  /*
  printf("M1:\n");
  dump_mat(m1,Size);
  printf("M2:\n");
  dump_mat(m2,Size);
  */
  // Applicaquer la fonction ddot
  dgemm(m3, m1, m2, Size);

  uint64_t stop = rdtsc(); 
  /*
  printf("M3:\n");
  dump_mat(m3,Size);
  // Afficher le résultat
  */
  printf("%d\t%ld\n",Size,stop-start);
  
  return 0;
}
