#include <stdio.h>
#include "ddot.h"

double ddot(double *v1, double *v2, size_t size)
{
  //printf("[ERROR] Not implemented...\n");
  double res=0.0;
  for (int i=0; i<size; i++)
    {
      res = res + (v1[i] * v2[i]);
    }
  return res;
}
