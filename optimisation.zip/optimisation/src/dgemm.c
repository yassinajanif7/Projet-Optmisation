#include <stdlib.h>
#include <stdio.h>
#include "dgemm.h"

double **create_mat(size_t size)
{
  double **m=(double **)malloc(sizeof(double*)*size);
  for (int i=0; i<size; i++)
    m[i]=(double *)malloc(sizeof(double)*size);
  return m;
}

void init_mat(double **m, double val, size_t size)
{
  for (int i=0; i<size; i++)
    {
      for (int j=0; j<size; j++)
	{
	  m[i][j]=val; 
	}
    }
}

void reset_mat(double **m, size_t size)
{
  for (int i=0; i<size; i++)
    {
      for (int j=0; j<size; j++)
	{
	  m[i][j]=0.0; 
	}
    }
  
}

void dump_mat(double **m, size_t size)
{
  for (int i=0; i<size; i++)
    {
      for (int j=0; j<size; j++)
	{
	  printf("%lf ",m[i][j]);
	}
      printf("\n");
    }
}

// Matrix multiplication
void dgemm(double **c, double **a, double **b, size_t size)
{
  for (int i=0; i<size; i++)
    {
      for (int j=0; j<size; j++)
	{
	  for (int k=0; k<size; k++)
	    {
	      c[i][j]=c[i][j] + a[i][k] * b[k][j]; 
	    }
	}
    }
}


