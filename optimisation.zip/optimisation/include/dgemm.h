#pragma once

double **create_mat(size_t size);

void init_mat(double **m, double val, size_t size);

void reset_mat(double **m, size_t size);

void dump_mat(double **m, size_t size);

// Matrix multiplication
void dgemm(double **c, double **a, double **b, size_t size);

