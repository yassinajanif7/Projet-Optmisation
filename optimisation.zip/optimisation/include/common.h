#pragma once

double *create_vect(size_t size);

void init_vect(double *vec, double value, size_t size);

void reset_vect(double *vec, size_t size);

void dump_vect(double *v, size_t size);


