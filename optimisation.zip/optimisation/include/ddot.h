#pragma once

// Fonction message
double ddot(double *v1, double *v2,size_t size);
